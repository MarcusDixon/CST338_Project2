/*
* Title: OtterLibrarySystemApp.java
* Abstract: This is the main for the program.
* Author: Marcus Dixon
* ID: 0721
* Date: 5/10/2015
*/

import javax.swing.JFrame;

public class OtterLibrarySystemApp
{
	 public static void main(String[] args)
	    {
	        JFrame frame = new OtterLibrarySystemFrame();
	        frame.setVisible(true);
	    }
}
